rootProject.name = "Busya2048"
include(":app")